﻿namespace Uppgiften_ASP.models
{
    public class LoginViewModel
    {
        public string Email { get; internal set; }
        public string Password { get; internal set; }
        public bool RememberMe { get; internal set; }
    }
}