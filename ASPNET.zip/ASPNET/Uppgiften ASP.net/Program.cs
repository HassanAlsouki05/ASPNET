﻿using Microsoft.AspNetCore.Identity;

var builder = WebApplication.CreateBuilder(args);

// Lägg till Identity-tjänster
builder.Services.AddIdentity<ApplicationUser, IdentityRole>()
    .AddEntityFrameworkStores<ApplicationDbContext>()
    .AddDefaultTokenProviders();

// Lägg till Razor Pages-tjänster
builder.Services.AddRazorPages();

var app = builder.Build();

// Konfigurera HTTP-pipeline
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    // Standard HSTS-värde är 30 dagar. Du kan vilja ändra detta för produktionsscenarier.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseRouting();
app.UseAuthorization();

app.MapStaticAssets();
app.MapRazorPages()
   .WithStaticAssets();

app.Run();
