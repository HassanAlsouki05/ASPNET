﻿internal class ApplicationUser
{
}