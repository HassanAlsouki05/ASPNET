﻿namespace Uppgiften_ASPNET.Controllers
{
    internal class HomeController
    {
        internal class Index
        {
        }
    }
}