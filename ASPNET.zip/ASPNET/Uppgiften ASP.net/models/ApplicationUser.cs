﻿namespace Uppgiften_ASPNET.Models
{
    public class ApplicationUser : IdentityUser
    {
        // eventuella extra properties
    }
}
