﻿document.addEventListener("DOMContentLoaded", function () {

    // =============================
    // FORMULÄRVALIDERING
    // =============================
    const form = document.querySelector("form");
    if (form) {
        form.addEventListener("submit", function (e) {
            const title = document.getElementById("Title");
            const description = document.getElementById("Description");

            let isValid = true;
            clearValidationErrors();

            if (!title || title.value.trim().length < 3) {
                showValidationError(title, "Titeln måste vara minst 3 tecken.");
                isValid = false;
            }

            if (!description || description.value.trim().length < 10) {
                showValidationError(description, "Beskrivningen måste vara minst 10 tecken.");
                isValid = false;
            }

            if (!isValid) {
                e.preventDefault();
            }
        });
    }

    // =============================
    // HJÄLPMETODER
    // =============================
    function showValidationError(element, message) {
        if (!element) return;

        const error = document.createElement("div");
        error.className = "text-danger";
        error.innerText = message;
        element.classList.add("is-invalid");
        element.parentNode.appendChild(error);
    }

    function clearValidationErrors() {
        document.querySelectorAll(".text-danger").forEach(e => e.remove());
        document.querySelectorAll(".is-invalid").forEach(e => e.classList.remove("is-invalid"));
    }

    // =============================
    // ALERT-MEDDELANDEN (t.ex. från TempData)
    // =============================
    const alertBox = document.querySelector(".alert-dismissible");
    if (alertBox) {
        setTimeout(() => {
            alertBox.classList.add("fade");
            setTimeout(() => alertBox.remove(), 500);
        }, 4000); // 4 sekunder
    }

});
